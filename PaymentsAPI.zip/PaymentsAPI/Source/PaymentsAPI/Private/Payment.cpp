// Copyright 2022 Manudog. All Rights Reserved.

#include "Payment.h"
#include "Json.h"
#include "Misc/Base64.h"
#include "Delegates/DelegateSignatureImpl.inl"
#include "HttpModule.h"
#include "Interfaces/IHttpResponse.h"

static bool apiLiveMode;
static FString apiClientID;
static FString apiSecret;

static FString apiToken;
static FString apiBaseUrl;
static FString apiPaymentID;

static FString approveURL;
static FString apiReturnURL;
static FString apiCancelURL;

// Sets default values
APayment::APayment()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void APayment::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void APayment::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Set the PayPal token
void APayment::SetCurrentToken(FString Token)
{
	apiToken = Token;
}

// Get the PayPal token
FString APayment::GetCurrentToken()
{
	return apiToken;
}

// Set Paypal Settings
FString APayment::GetSettings(bool liveMode, FString clientID, FString secret, FString returnURL, FString cancelURL)
{
	apiLiveMode = liveMode;
	apiClientID = clientID;
	apiSecret = secret;
	apiReturnURL = returnURL;
	apiCancelURL = cancelURL;

	// If the payments are in test phase or live
	if (apiLiveMode) {
		apiBaseUrl = "https://api.paypal.com";
	}
	else {
		apiBaseUrl = "https://api-m.sandbox.paypal.com";
	}

	FString AuthBase64 = FBase64::Encode(apiClientID + ":" + apiSecret);

	return AuthBase64;
}

// Recovery of the PayPal token
void APayment::GetPaypalToken(FString AuthBase64, FHttpRequestResponse Callback)
{

	FHttpRequestRef Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(apiBaseUrl + "/v1/oauth2/token");
	Request->SetVerb("POST");
	Request->SetHeader("Authorization", "Basic " + AuthBase64);
	Request->SetHeader(TEXT("User-Agent"), TEXT("X-UnrealEngine-Agent"));
	Request->SetHeader("Content-Type", "application/x-www-form-urlencoded");
	Request->SetContentAsString("grant_type=client_credentials");
	Request->OnProcessRequestComplete().BindLambda([Callback](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
		{
			Callback.ExecuteIfBound(Response->GetContentAsString(), Response->GetResponseCode(), bWasSuccessful);
		});
	Request->ProcessRequest();
}

// Token Response API
void APayment::ResponseToken(FString Response)
{

	TSharedPtr<FJsonObject> ResponseObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(*Response);
	FJsonSerializer::Deserialize(Reader, ResponseObj);

	SetCurrentToken(ResponseObj->GetStringField("access_token"));

}

// Send create payment
void APayment::PaypalPayment(FString productName, float amount, FString currency, FHttpRequestResponse Callback)
{

	apiPaymentID = "";

	float amountRound = floor(amount * 100) / 100;
	FString amountPaypal = FString::SanitizeFloat(amountRound);
	FString PaypalRequestID = FString::SanitizeFloat(FMath::RandRange(0, 9));

	FHttpRequestRef Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(apiBaseUrl + "/v2/checkout/orders");
	Request->SetVerb("POST");
	Request->SetHeader("Authorization", "Bearer " + GetCurrentToken());
	Request->SetHeader("PayPal-Request-Id", PaypalRequestID);
	Request->SetHeader("Content-Type", "application/json");
	Request->SetContentAsString("{\"intent\": \"AUTHORIZE\",\"purchase_units\": [{\"amount\": {\"currency_code\": \"" + currency + "\",\"value\" : \"" + amountPaypal + "\"}}],\"payment_source\": {\"paypal\": {\"experience_context\": {\"user_action\": \"PAY_NOW\",\"return_url\": \"" + apiReturnURL + "\",\"cancel_url\": \"" + apiCancelURL + "\"}}}}");
	Request->OnProcessRequestComplete().BindLambda([Callback](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
		{
			Callback.ExecuteIfBound(Response->GetContentAsString(), Response->GetResponseCode(), bWasSuccessful);
		});
	Request->ProcessRequest();

}

// Payment Response API
void APayment::ResponsePayment(FString Response)
{

	TSharedPtr<FJsonObject> ResponseObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(*Response);
	FJsonSerializer::Deserialize(Reader, ResponseObj);

	apiPaymentID = ResponseObj->GetStringField("id");

	if (apiLiveMode) {
		approveURL = "https://www.paypal.com/checkoutnow?token=" + apiPaymentID;
	}
	else {
		approveURL = "https://www.sandbox.paypal.com/checkoutnow?token=" + apiPaymentID;
	}

	FPlatformProcess::LaunchURL(*approveURL, NULL, NULL);
	//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Black, FString::Printf(TEXT("Response Payment: %s"), *ResponseObj->GetStringField("id")));

}

// Check confirmed payment
void APayment::ConfirmPayment(FHttpRequestResponse Callback) {

	FHttpRequestRef Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(apiBaseUrl + "/v2/checkout/orders/" + apiPaymentID);
	Request->SetVerb("GET");
	Request->SetHeader("Authorization", "Bearer " + GetCurrentToken());
	Request->OnProcessRequestComplete().BindLambda([Callback](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
		{
			Callback.ExecuteIfBound(Response->GetContentAsString(), Response->GetResponseCode(), bWasSuccessful);
		});
	Request->ProcessRequest();

}

// Confirm Response API
FString APayment::ResponseConfirm(FString Response)
{

	TSharedPtr<FJsonObject> ResponseObj;
	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(*Response);
	FJsonSerializer::Deserialize(Reader, ResponseObj);

	return ResponseObj->GetStringField("status");

}

// Authorize payment
void APayment::AuthorizePayment(FHttpRequestResponse Callback) {

	FHttpRequestRef Request = FHttpModule::Get().CreateRequest();
	Request->SetURL(apiBaseUrl + "/v2/checkout/orders/" + apiPaymentID + "/authorize");
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", "application/json");
	Request->SetHeader("Authorization", "Bearer " + GetCurrentToken());
	Request->OnProcessRequestComplete().BindLambda([Callback](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
		{
			Callback.ExecuteIfBound(Response->GetContentAsString(), Response->GetResponseCode(), bWasSuccessful);
		});
	Request->ProcessRequest();

}

// Redirect URL
void APayment::RedirectURL()
{
	FPlatformProcess::LaunchURL(*approveURL, NULL, NULL);
}