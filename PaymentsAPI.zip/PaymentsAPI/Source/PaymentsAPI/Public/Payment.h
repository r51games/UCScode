// Copyright 2022 Manudog. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Http.h"
#include "Payment.generated.h"

DECLARE_DYNAMIC_DELEGATE_ThreeParams(FHttpRequestResponse, FString, ResponseString, int, HttpStatus, bool, Success);

UCLASS()
class PAYMENTSAPI_API APayment : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	APayment();

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static FString GetSettings(bool liveMode, FString clientID, FString secret, FString returnURL, FString cancelURL);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void GetPaypalToken(FString AuthBase64, FHttpRequestResponse Callback);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void ResponseToken(FString Response);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void PaypalPayment(FString productName, float amount, FString currency, FHttpRequestResponse Callback);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void SetCurrentToken(FString Token);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static FString GetCurrentToken();

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void ResponsePayment(FString Response);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void ConfirmPayment(FHttpRequestResponse Callback);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static FString ResponseConfirm(FString Response);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void AuthorizePayment(FHttpRequestResponse Callback);

	UFUNCTION(BlueprintCallable, Category = "Payments API")
		static void RedirectURL();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
